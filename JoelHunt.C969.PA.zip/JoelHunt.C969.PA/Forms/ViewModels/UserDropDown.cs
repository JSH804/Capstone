﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JoelHunt.C969.PA.Forms.ViewModels
{
    public class UserDropDown
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
